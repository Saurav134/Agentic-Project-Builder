// Todo App JavaScript Logic

// DOM Elements - using exact IDs from HTML
const todoInput = document.getElementById('todo-input');
const submitBtn = document.getElementById('submit-btn');
const todoList = document.getElementById('todo-list');
const todoTemplate = document.getElementById('todo-item-template');

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    loadTodos();
    setupEventListeners();
});

// Set up event listeners
function setupEventListeners() {
    // Add todo on button click
    submitBtn.addEventListener('click', addTodo);
    
    // Add todo on Enter key press
    todoInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            addTodo();
        }
    });
}

// Load todos from localStorage
function loadTodos() {
    const todos = JSON.parse(localStorage.getItem('todos')) || [];
    todos.forEach(todo => {
        createTodoElement(todo.text, todo.completed, todo.id);
    });
}

// Save todos to localStorage
function saveTodos() {
    const todos = [];
    const todoItems = todoList.querySelectorAll('.todo-item');
    
    todoItems.forEach(item => {
        const text = item.querySelector('.todo-text').textContent;
        const completed = item.querySelector('.todo-checkbox').checked;
        const id = item.dataset.id;
        
        todos.push({
            id: id,
            text: text,
            completed: completed
        });
    });
    
    localStorage.setItem('todos', JSON.stringify(todos));
}

// Add a new todo
function addTodo() {
    const todoText = todoInput.value.trim();
    
    if (todoText === '') {
        alert('Please enter a todo item!');
        return;
    }
    
    const todoId = Date.now().toString();
    createTodoElement(todoText, false, todoId);
    
    // Clear input
    todoInput.value = '';
    
    // Save to localStorage
    saveTodos();
}

// Create todo element from template
function createTodoElement(text, completed, id) {
    // Clone the template
    const templateContent = todoTemplate.content.cloneNode(true);
    const todoItem = templateContent.querySelector('.todo-item');
    
    // Set up the todo item
    todoItem.dataset.id = id;
    
    // Set checkbox state
    const checkbox = todoItem.querySelector('.todo-checkbox');
    checkbox.checked = completed;
    
    // Set text content
    const textSpan = todoItem.querySelector('.todo-text');
    textSpan.textContent = text;
    
    // Add completed styling if checked
    if (completed) {
        textSpan.classList.add('completed');
    }
    
    // Add event listeners
    checkbox.addEventListener('change', function() {
        if (this.checked) {
            textSpan.classList.add('completed');
        } else {
            textSpan.classList.remove('completed');
        }
        saveTodos();
    });
    
    // Delete button functionality
    const deleteBtn = todoItem.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', function() {
        todoItem.remove();
        saveTodos();
    });
    
    // Add to the list
    todoList.appendChild(todoItem);
}

// Clear all todos (optional function - can be called from a button if needed)
function clearAllTodos() {
    if (confirm('Are you sure you want to delete all todos?')) {
        todoList.innerHTML = '';
        localStorage.removeItem('todos');
    }
}

// Mark all as complete (optional function)
function markAllComplete() {
    const checkboxes = todoList.querySelectorAll('.todo-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = true;
        checkbox.dispatchEvent(new Event('change'));
    });
}

// Filter functions (optional - can be extended)
function filterTodos(filter) {
    const todoItems = todoList.querySelectorAll('.todo-item');
    
    todoItems.forEach(item => {
        const checkbox = item.querySelector('.todo-checkbox');
        
        switch(filter) {
            case 'all':
                item.style.display = 'flex';
                break;
            case 'active':
                item.style.display = checkbox.checked ? 'none' : 'flex';
                break;
            case 'completed':
                item.style.display = checkbox.checked ? 'flex' : 'none';
                break;
        }
    });
}